
function subscribe() {
    alert("Thank you for joining the Bee Surreal movement!");
}
